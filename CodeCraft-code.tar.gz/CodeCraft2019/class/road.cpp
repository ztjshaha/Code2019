#include "road.h"
/*void Road::set(int channel,int length,int flag_bothway,CarState &a)
{
  struct  CarState a[channel][length][flag_bothway];
}*/

//   void Road::input_data(int x,int y,int z,int flag_data,int car_dirction_data,int car_id_data,int car_position_data,int car_speed_data,int car_passed_data,int car_pass_data)
//    {
//     situation[x][y][z].flag=flag_data;
//     situation[x][y][z].car_dirction=car_dirction_data;    
//     situation[x][y][z].car_id=car_id_data;    
//     situation[x][y][z].car_position=car_position_data;    
//     situation[x][y][z].car_speed=car_speed_data;
//     situation[x][y][z].car_passed.push_back(car_passed_data);    
//     situation[x][y][z].car_pass.push_back(car_pass_data);    
//    }