#include "cross.h"
#include "vector"
void Cross::cross(int cross_num,int car_num,vector<int>&car)
{

}