#include "car.h"
#include "math.h"
/*void Car::Car_status(Car_Situation situation)
{
    
    // int flag;
    //int car_dirction;
    int Road_Id;
    int Next_Cross;
    int Channel;
    //int car_id;
    //int	car_position;
    int Car_Speed;
    bool Token;  //第一优先级车辆标志，是则为1，不是则为0
    vector <string> car_passed;
    vector <string> car_pass;
    int car_turn;	//D 	:	1
			//L	:	0
			//R	:	-1
}*/
void Car::car_init()
{
  
}


