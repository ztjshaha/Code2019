#ifndef MAP_H_
#define MAP_H_
#include <iostream>
#include "string"
#include "road.h"
#include "vector"
using namespace std;
//void function(int [][][] a);
//你的代码写在这里
class map//:public Road
{
public:
  //void map3d(int road_num,const int map3d[][][4]);
  //void Dijkstra(int cross_num);
  //void Dijkstra(int cross_num,vector<vector<vector<int>>> path,vector<vector<int>> road_length);
};
#endif