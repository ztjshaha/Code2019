#include "map.h"

//void function(int a[][][])

//{
  
//}
//void map::map3d(int road_num,const int map3d[][][4])
//{
  /*int map3d [road_num][road_num][4];
	for(int j=0;j<road_num;j++)
	{
	 map3d[road[j].start-1][road[j].end-1][0]=road[j].id;
	 map3d[road[j].start-1][road[j].end-1][1]=road[j].length;
	 map3d[road[j].start-1][road[j].end-1][2]=road[j].limit_speed;
	 map3d[road[j].start-1][road[j].end-1][3]=road[j].channel;
	 if(road[j].flag_bothway==1)
	 {
	   map3d[road[j].end-1][road[j].start-1][0]=map3d[road[j].start-1][road[j].end-1][0];
	   map3d[road[j].end-1][road[j].start-1][1]=map3d[road[j].start-1][road[j].end-1][1];
	   map3d[road[j].end-1][road[j].start-1][2]=map3d[road[j].start-1][road[j].end-1][2];
	   map3d[road[j].end-1][road[j].start-1][3]=map3d[road[j].start-1][road[j].end-1][3];
	  }
	  else{
	    map3d[road[j].end-1][road[j].start-1][0]=-1;
	    map3d[road[j].end-1][road[j].start-1][1]=-1;
	    map3d[road[j].end-1][road[j].start-1][2]=-1;
	    map3d[road[j].end-1][road[j].start-1][3]=-1;
	  }
	}*/
//}
